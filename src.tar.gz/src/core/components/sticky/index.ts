export { KTSticky } from './sticky';
export { KTStickyConfigInterface, KTStickyInterface } from './types';
