export { KTScrollable } from './scrollable';
export { KTScrollableConfigInterface, KTScrollableInterface } from './types';
