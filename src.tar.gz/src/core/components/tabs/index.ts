export { KTTabs } from './tabs';
export { KTTabsConfigInterface, KTTabsInterface } from './types';
