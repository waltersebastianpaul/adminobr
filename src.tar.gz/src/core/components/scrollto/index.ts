export { KTScrollto } from './scrollto';
export { KTScrolltoConfigInterface, KTScrolltoInterface } from './types';
